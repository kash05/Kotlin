package com.example.constraintlayout;

import android.app.Activity;

public class recycler extends Activity {
}
