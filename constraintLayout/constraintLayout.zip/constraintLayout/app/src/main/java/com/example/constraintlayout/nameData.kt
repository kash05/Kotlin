package com.example.constraintlayout

data class nameData(val name:String, val age:Int, val flagId: Int){

}

